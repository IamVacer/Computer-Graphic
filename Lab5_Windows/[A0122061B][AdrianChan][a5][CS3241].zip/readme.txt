Name: Adrian Chan Ee Ray
Matric Number: A0122061B

Primative and Transformation: 
	Transformation: glRotate and glTranslate
	Drawing: glVertex2d 
	Mathematics: Trigonometry
	texture: glTexCoord2d

What am I drawing: 
	When theres 2 assignments and 3 finals due on week 13. I absolutely do not have time to become an architect to build a design house. As a life of an SOC students, we practically do not have a house. We work in a factory

	Drill: I don't have time to develop a house, its still being drilled in the progress.

	Factory: As an SOC student, we never get to leave our workstation back to home. WE DONT HAVE A HOME. THERES NO WAY OUT BECAUSE THERE IS NO DOOR. IN IT YOU SEE THE FIRE BURNING, TILL THE LATE NIGHT. IT NEVER ENDS. HELP

	Paper planes: In the midst of rushing, I have occasionally resort to complacency and folding paper planes and throwing out of the factory. They are all filled with the texture present in the library.

Coolest things in my Object:
	Animation, Virtual fire

Modified methods:
	Using of texture to create animated fire.

Things TA should know:
	THIS ASSIGNMENT IS KILLING ME. SAVE ME FROM THE FACTORY