Name: Adrian Chan Ee Ray
Matric Number: A0122061B

Primative and Transformation: 
	Transformation: glRotate and glTranslate
	Drawing: glVertex2d 
	Mathematics: Trigonometry and Differentiation

What am I drawing with savefile.txt: 
	Once O(for displayObject) is activated, prepare for enhanced experience of objects travelling through space and time. 

	If the sets of control points(4) are close to one another, it will look like psychedelic worms crawing along the curves. 

	Deactivate the curve, points, tangent, and lines for a full visual experience.

Coolest things in my Object:
	Worms are created using simple trigo functions on different variables.

	Added buttons: 
		D: Backspace
		S: Show Beizer curves (useful for focusing on the psychedelic worms as it travels around)

Things TA should know:
	The saving format to save.txt has been altered from the original template. If savefile.txt is read with a different main.cpp or vice versa, the coordinates will be messed up.
	Feel free to play any trippy music with the project to enhance your experience. 
	I strongly recommend "Falling Up - Song in the Air" https://youtu.be/OeWmW6XFe2k?t=3m50s from the 3 mins 50 sec section of the music.