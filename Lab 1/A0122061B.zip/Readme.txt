Matric Number: 
	A0122061B

Primative transformation used: 
	Scale, transform, rotate, rotation

What am I drawing:
	The flip table meme, 
	press "a" to animate it in normal state
	once you are angry, press "s"
	both buttons can be pressed repeatedly

Methods you have modified: 
	the drawCircle method given from tutorial to draw the "( )". recursion was used as well and to create the animation, methods were modified from existing thus drawing the other scenes wasnt difficult.

What is the coolest thing: 
	It is the encapsulation of my emotion during these few weeks of getting Visual Studio to work on my computer, theres animation in this as well
