Name: Adrian Chan Ee Ray
Matric Number: A0122061B

Primative and Transformation: 
	glRotate and glTranslate with trigo parametric equations

What am I drawing: 
	A solar system if planets are able to experience off center orbits, unique orbit patterns and planets have the ability to change colour

	It also has a clock feature.

Coolest things in my Drawing:
	With Trigo parametric equation, I have the freedom to manipulate the manner of orbit to which ever manner i can.

Things TA should know:
	The clock is a smooth one (it doesnt tick). The hour and minute hand moves gradually towards the next hour or minute respectively. The the present moons also help indicate every second, minute and hour